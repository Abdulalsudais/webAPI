﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIController.Models
{
    public class Repository : iRepository
    {
        private Dictionary<int, Reservation> items;
        public Repository()
        {
            items = new Dictionary<int, Reservation>();
            new List<Reservation> {
                new Reservation {Id=1, Name = "Ankit", StartLocation = "Chennai", EndLocation="Bangalore" },
                new Reservation {Id=2, Name = "Babulu", StartLocation = "Chennai", EndLocation="Kolkata" },
                new Reservation {Id=3, Name = "Radha", StartLocation = "Delhi", EndLocation="Chennai" }
                }.ForEach(r => AddReservation(r));
        }
        Reservation iRepository.this[int id] => items.ContainsKey(id)?items[id]:null;

        IEnumerable<Reservation> iRepository.Reservations => items.Values;

        public Reservation AddReservation(Reservation reservation)
        {
            if (reservation.Id == 0)
            {
                int key = items.Count;
                while (items.ContainsKey(key)) { key++; };
                reservation.Id = key;
            }
            items[reservation.Id] = reservation;
            return reservation;
        }

        public void DeleteReservation(int id) => items.Remove(id);

        public Reservation UpdateReservation(Reservation reservation) => AddReservation(reservation);

        
    }
}
